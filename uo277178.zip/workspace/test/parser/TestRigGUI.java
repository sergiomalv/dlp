package parser;

public class TestRigGUI {
	
	public static void main(String... args) throws Exception {
		org.antlr.v4.gui.TestRig.main(new String[]{"parser.Pmm", "program", "-gui", "input.txt"});
	}
	

}
