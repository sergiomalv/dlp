package ast.statements;

import ast.AstNode;

/**
 * Interface that represents a statement
 * @author Sergio
 */
public interface Statement extends AstNode {
}
