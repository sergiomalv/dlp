package ast.types;

import ast.AstNode;

/**
 * Interface of types
 */
public interface Type extends AstNode {
}
